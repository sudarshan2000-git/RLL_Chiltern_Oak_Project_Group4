package com.project.rll.pages;
 
import java.time.Duration;
 
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
 
public class FilterPage {
	WebDriver driver;
	public FilterPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	//Locator
	@FindBy(using="//input[@class=\'main-search__input\']",how=How.XPATH)
	private WebElement searchElment_text_box;
	
	@FindBy(using="//button[@type=\"submit\"]",how=How.XPATH)
	private WebElement search_button;
	
	@FindBy(using="//input[@id='CCPriceRangeMin']",how=How.XPATH)
    private WebElement price_Min;
	
	@FindBy(using="//input[@id='CCPriceRangeMax']",how=How.XPATH)
    private WebElement price_Max;
	
	
	@FindBy(using="//label[@title=\"White\"]",how=How.XPATH)
	private WebElement choose_color_check_box;
	
	@FindBy(using="//span[@class=\"cc-checkbox__label\"]",how=How.XPATH)
    private WebElement choose_style_check_box;
	
	
	
	// Methods
	public void searchProduct()  {
		searchElment_text_box.clear();
		searchElment_text_box.sendKeys("table");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		search_button.click();
 
	}
	
 
	public void SearchElementPrice()  {
		price_Min.sendKeys("0");
		price_Max.sendKeys("20");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	public void chooseColor()  {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		choose_color_check_box.click();
	}
	public void chooseStyle()  {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		choose_style_check_box.click();
		
	}
}