package com.project.rll.runners;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "D:\\practice project\\RLL\\projec integrate\\Final\\RLL_Project_Childern-Oak\\RLL_Project_Childern-Oak\\RLL_Project_Childern-Oak\\src\\test\\resources\\features\\Asignup.feature", 
	glue = {"com/project/rll/steps"},
			
			plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
					"pretty",}
	)
public class TestRunner {

}
