package com.project.rll.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Reviewpage 
{
	
	WebDriver driver;
	public Reviewpage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(this.driver, this);
	}
	
	 @FindBy(xpath="//a[normalize-space()='5-Star Reviews']")
	    public WebElement clickOnReviewButonLink;
	 

	    @FindBy(xpath="//div[@class='WriteReviewStars-container']//a[5]//i[1]") 
	    public WebElement clickOnStar5;
	    
	    @FindBy(xpath="//div[@class='WriteReviewStars-container']//a[4]//i[1]") 
	    public WebElement clickOnStar4;
	    
	    @FindBy(xpath="//div[@class='WriteReviewStars-container']//a[3]//i[1]") 
	    public WebElement clickOnStar3;
	    
	    @FindBy(xpath="//div[@class='WriteReviewStars-container']//a[2]//i[1]") 
	    public WebElement clickOnStar2;
	    
	    @FindBy(xpath="//div[@class='WriteReviewStars-container']//a[1]//i[1]") 
	    public WebElement clickOnStar1;
	    
	    @FindBy(xpath="//textarea[@id='comments']")
	    public WebElement writeReview;
	    
	    @FindBy(xpath="//input[@id='name']")
	    public WebElement enterName;
	    
	    @FindBy(xpath="//input[@id='email']")
	    public WebElement enterEmail;
	   
	    @FindBy(xpath="//button[@id='submitReview']")
	    public WebElement clickOnSubmit;
	    
	    @FindBy(xpath="//div[@class='TextHeading TextHeading--lg u-marginBottom--lg u-textCenter--all']")
	    public WebElement thankyouText;
	    
	    @FindBy(xpath="//div[@id='review_error_main_output']")
	    public WebElement submittingErrorMessage;
	    
	    
	  //div[@class='TextHeading TextHeading--lg u-marginBottom--lg u-textCenter--all']
	    

	    public void clickOnReview() {
	    	clickOnReviewButonLink.click();	    
	    	}

	    public void clickOnStar(int starnum) 
	    {
	    	WebElement star[] = {clickOnStar1,clickOnStar2,clickOnStar3,clickOnStar4,clickOnStar5};
	    		WebElement stars = star[starnum-1];
	    		 stars.click();
	    }
	    
	    public String checkTitle() {
	    	return driver.getTitle();
	   
	    }
	    
	    public void writeReview(String review) {
	     writeReview.sendKeys(review);
	   
	    }
	    
	    public void enterName(String Name) {
	    	 enterName.sendKeys(Name);
	   
	    }
	    
	    public void enterEmail(String Email) {
	    	 enterEmail.sendKeys(Email);

	    }
	
	    public void clickOnSubmit() {
	    	 clickOnSubmit.click();;

	    }

		public String validate_Url() {
			// TODO Auto-generated method stub
			return driver.getCurrentUrl();
		}
}
