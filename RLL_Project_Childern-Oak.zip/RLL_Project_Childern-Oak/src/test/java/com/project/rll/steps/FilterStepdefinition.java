package com.project.rll.steps;
 
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
 
import com.project.rll.pages.FilterPage;
 
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
 
public class FilterStepdefinition {
 
	FilterPage page=new FilterPage(BaseTest.driver);
	private static final Logger logger = LogManager.getLogger(FilterStepdefinition.class);
	
	@Given("user navigates to the website chilternoakfurniture.co.uk")
	public void user_navigates_to_the_website_chilternoakfurniture_co_uk() {
		logger.info("User navigate to product catlog page");
	}
 
	@Given("search the product")
	public void search_the_product()  {
		logger.info("Item searched");
		page.searchProduct();
	}
 
	@Then("added filter successfully")
	public void added_filter_successfully() {
		logger.info("Filter operation performed successfully.");
	}
 
	@Given("Search the Element Price")
	public void Search_the_element_price()  {
	   logger.info("Enters elements price Successfully");
	   page.SearchElementPrice();
	}
 
	@Then("user gets Search results")
	public void user_gets_search_results() {
		String expected = "No search results";
		 String actual ="Searchresultspage" ;
		 Assert.assertEquals(actual,expected);
	    	}
 
	@Given("choose the color")
	public void choose_the_color()  {
		logger.info("User choose the color of product");
		page.chooseColor();
	}
	
	@Given("choose the style")
	public void choose_the_style()  {
		logger.info("User choose the color of product");
		page.chooseStyle();
	}
	
 
}