package com.project.rll.steps;

import io.cucumber.java.en.Given;


import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.And;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.github.dockerjava.api.model.Info;
import com.project.rll.pages.Reviewpage;
import com.project.rll.pages.Searchpage;

	public class ReviewAndRatingSteps 
	{
		Logger logger = LogManager.getLogger(ReviewAndRatingSteps.class);
		
	     Reviewpage reviewPage=new Reviewpage(BaseTest.driver);
	     
	   public  String actualErrrormessage;

	    @Given("I am on the Chilternoak Furniture Homepage")
	    public void iAmOnHomepage() {
	        // Add code to navigate to the homepage
	    	logger.info("Chilternoak Furniture Homepage");
	    }

	    @When("I click on the 'Rating and Review' link")
	    public void iClickOnRatingAndReviewLink() {
	    	logger.info("click on the 'Rating and Review' link");
	    	
	    	reviewPage.clickOnReview();
	        // Add code to click on the 'Rating and Review' link
	       
	    }

	    @Then("I should be navigated to the Review and Rating Page")
	    public void iShouldBeNavigatedToReviewAndRatingPage() {
	    	logger.info("Chilternoak Furniture review pge");
	    	
	        // Add code to verify navigation to the Review and Rating page
//	        String pageTitle = driver.getTitle();
	        // Assert pageTitle or use any other verification method
	    }

	    @And("I capture the title of the page")
	    public void iCaptureTitleOfPage() {
	   String titleText =  reviewPage.checkTitle();
	   
	        // Add code to capture the title of the page if needed
	    	logger.info("titlecapture");
	    	System.out.println(titleText);
	    }

	     @Then("I select stars as {string} on the page")
	     public void i_select_stars_as_on_the_page(String string)
	     {
	    	 int starNumber = Integer.parseInt(string);
	    	 reviewPage.clickOnStar(starNumber);
	     }

	    @And("I enter Review as {string} on the page")
	    public void iEnterReviewID(String review) {
	        // Add code to enter Review ID on the page
	    	reviewPage.writeReview(review);
	    }

	    @And("I enter Name as {string} on the page")
	    public void iEnterName(String name) {
	    	
	    	reviewPage.enterName(name);
	        // Add code to enter Name on the page
	    }

	    @And("I enter Email as {string} on the page")
	    public void iEnterEmail(String email) {
	        // Add code to enter Email on the page
	    	
	    	reviewPage.enterEmail(email);
	    }

	    @And("I click on the submit button")
	    public void iClickOnSubmitButton() throws InterruptedException {
	        // Add code to click on the submit button
	    	logger.info("submitting thank you");
	    	reviewPage.clickOnSubmit();
	    //System.out.println(reviewPage.thankyouText.getText());
	    	Thread.sleep(2000);
	    }

	    @Then("I should see a confirmation message indicating successful review submission")
	    public void iShouldSeeConfirmationMessage() throws InterruptedException {
	        // Add code to verify the presence of a confirmation message
	    	  
	    	String ErrorMessage = "* There was a problem submitting your review; please try again later.";
	    	String expectedTitle = "REVIEWS.co.uk";
	    	String actualTitle = reviewPage.checkTitle();
//	    	System.out.println("---" + reviewPage.checkTitle()+ "---");
	    	
	    	try {
				 actualErrrormessage = reviewPage.submittingErrorMessage.getText();
				
			} catch (Exception e) 
	    	{
				System.out.println("unable to find the error Message");
				// TODO: handle exception
			}
	    	
	    	if(ErrorMessage.equals(actualErrrormessage)) 
	    	{
		    System.out.println("Error message encountered");;
	    	logger.info(ErrorMessage);
	    	}
	    	
	    	Assert.assertEquals(actualTitle,expectedTitle);
	    	logger.info("Page confirmation completed");
	    	
	    }//Chiltern Oak Furniture Reviews - Read 3,101 Genuine Customer Reviews | www.chilternoakfurniture.co.uk
}//REVIEWS.co.uk
